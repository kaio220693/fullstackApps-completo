﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace CircodeAppsTDS10
{
    public partial class FrmMediaConsumo : Form
    {
        public FrmMediaConsumo()
        {
            InitializeComponent();
        }

        private void btnFechar_Click(object sender, EventArgs e)
        {
            this.Close();
        }

        private void btnCalcular_Click(object sender, EventArgs e)
        {
            double km, litros, resultado, total;
            km = Convert.ToDouble(txtKM.Text);
            litros = Convert.ToDouble(txtLitros.Text);
            resultado = km/litros;
            lblMedia.Text = resultado.ToString("F")+" Km/L";
            lblTotal.Text = CBXCombustivel.Text;
            if(CBXCombustivel.Text== "Etanol")
            {
                total = 4.39 * litros;
                lblTotal.Text ="R$" + Convert.ToString(total);
               
            } else if (CBXCombustivel.Text=="Gasolina")
            {
                    total= 5.19 * litros;
                    lblTotal.Text ="R$" + Convert.ToString(total);
            }
            else if (CBXCombustivel.Text=="Diesel")
            {
                total= 5.16 * litros;
                lblTotal.Text = "R$" +Convert.ToString(total);
            }
        }
    }
}
