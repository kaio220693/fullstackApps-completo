﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace CircodeAppsTDS10
{
    public partial class FrmConversorTemperatura : Form
    {
        public FrmConversorTemperatura()
        {
            InitializeComponent();
        }

        private void label2_Click(object sender, EventArgs e)
        {
            this.Close();
        }

        private void btnFechar_Click(object sender, EventArgs e)
        {
            this.Close();
        }

        private void btnCalcular_Click(object sender, EventArgs e)
        {
            double temp, temperatura;
            if (cbxDe.Text == cbxPara.Text)
            {
                MessageBox.Show("As duas temperaturas são iguais!");
            }
            else if (cbxDe.Text == "Celsius" && cbxPara.Text == "Kelvin")
            {
                temperatura = Convert.ToDouble(txtTemperatura.Text);
                temp = temperatura + 273.15;
                lblResultado.Text = temp.ToString("F");
            }
            else if (cbxDe.Text == "Celsius" && cbxPara.Text == "Fahrenheit")
            {
                temperatura = Convert.ToDouble(txtTemperatura.Text);
                temp = (temperatura * 9/5)+ 32;
                lblResultado.Text = temp.ToString("F");
            }
            else if (cbxDe.Text == "Kelvin" && cbxPara.Text == "Celsius")
            {
                temperatura = Convert.ToDouble(txtTemperatura.Text);
                temp = temperatura - 273.15;
                lblResultado.Text = temp.ToString("F");
            }
            else if (cbxDe.Text == "Kelvin" && cbxPara.Text == "Fahrenheit")
            {
                temperatura = Convert.ToDouble(txtTemperatura.Text);
                temp = (temperatura -273.15) * 9/5 + 32;
                lblResultado.Text = temp.ToString("F");
            }
            else if (cbxDe.Text == "Fahrenheit" && cbxPara.Text == "Kelvin")
            {
                temperatura = Convert.ToDouble(txtTemperatura.Text);
                temp = (temperatura - 32) *5 / 9 + 273.15;
                lblResultado.Text = temp.ToString("F");
            }
            else if (cbxDe.Text == "Fahrenheit" && cbxPara.Text == "Celsius")
            {
                temperatura = Convert.ToDouble(txtTemperatura.Text);
                temp = (temperatura - 32)* 5 / 9;
                lblResultado.Text = temp.ToString("F");
            }
        }
    }
}
