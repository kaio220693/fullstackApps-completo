﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Diagnostics.Eventing.Reader;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace CircodeAppsTDS10
{
    public partial class FrmIR : Form
    {
        public FrmIR()
        {
            InitializeComponent();
        }

        private void btnFechar_Click(object sender, EventArgs e)
        {
            this.Close();
        }

        private void FrmIR_Load(object sender, EventArgs e)
        {
            this.ActiveControl = txtSalario;
            txtSalario.Focus();
        }

        private void textBox1_KeyPress(object sender, KeyPressEventArgs e)
        {
            if (!Char.IsDigit(e.KeyChar) && e.KeyChar != (char)8 && e.KeyChar != (char)44)
            {
                e.Handled = true;
            }
        }

        private void btnCalcular_Click(object sender, EventArgs e)
        {
            if (txtSalario.Text == "")
            {
                MessageBox.Show("Não há cálculos sem valores! Por favor, preencha todos os campos.", "Erro", MessageBoxButtons.OK, MessageBoxIcon.Error);
            }
            else
            {
                double salario, resultado;
                salario = Convert.ToDouble(textBox1.Text);
                txtSalario.Text = "";
                if (salario <= 2112.00)
                {
                    resultado = (salario * 0);
                    lblResultado1.Text = "Isento";
                    lblResultado2.Text = resultado.ToString("F");
                }
                else if (salario >= 2112.01 && salario <= 2826.65)
                {
                    resultado = (salario * 0.075);
                    lblResultado1.Text = "7,5%";
                    lblResultado2.Text = resultado.ToString("F");
                }
                else if (salario >= 2826.66 && salario <= 3751.05)
                {
                    resultado = (salario * 0.15);
                    lblResultado1.Text = "15%";
                    lblResultado2.Text = resultado.ToString("F");
                }
                else if (salario >= 3751.06 && salario >= 4664.68)
                {
                    resultado = (salario * 0.225);
                    lblResultado1.Text = "22,5";
                    lblResultado2.Text = resultado.ToString("F");
                }
                else if (salario >= 4664.68) 
                {
                    resultado = (salario * 0.275);
                    lblResultado1.Text = "27,5%";
                    lblResultado2.Text = resultado.ToString("F");
                }
                
            }
        }
    }
}
